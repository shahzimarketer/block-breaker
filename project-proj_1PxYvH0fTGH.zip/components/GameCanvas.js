function GameCanvas() {
  const [isPlaying, setIsPlaying] = React.useState(false);
  const [isFullscreen, setIsFullscreen] = React.useState(false);
  const [score, setScore] = React.useState(0);
  const gameRef = React.useRef(null);
  const canvasRef = React.useRef(null);
  
  try {
    React.useEffect(() => {
      if (canvasRef.current && typeof GameEngine !== 'undefined') {
        const game = new GameEngine(canvasRef.current, setScore);
        gameRef.current = game;
        
        return () => {
          if (gameRef.current) {
            gameRef.current.destroy();
          }
        };
      }
    }, []);

    const startGame = () => {
      if (gameRef.current) {
        gameRef.current.start();
        setIsPlaying(true);
      }
    };

    const resetGame = () => {
      if (gameRef.current) {
        gameRef.current.reset();
        setIsPlaying(false);
        setScore(0);
      }
    };

    const toggleFullscreen = () => {
      const canvas = canvasRef.current;
      if (!document.fullscreenElement) {
        canvas.requestFullscreen().then(() => {
          setIsFullscreen(true);
        });
      } else {
        document.exitFullscreen().then(() => {
          setIsFullscreen(false);
        });
      }
    };

    return (
      <div className="flex flex-col items-center space-y-6" data-name="game-canvas" data-file="components/GameCanvas.js">
        <div className="flex items-center space-x-8 mb-4">
          <div className="text-2xl font-bold text-[var(--text-primary)]">
            Score: <span className="text-[var(--accent-color)]">{score}</span>
          </div>
        </div>
        
        <canvas
          ref={canvasRef}
          width="800"
          height="400"
          className="game-canvas max-w-full"
        />
        
        <div className="flex flex-wrap gap-4 justify-center">
          <button
            onClick={startGame}
            className="btn-primary flex items-center space-x-2"
          >
            <div className="icon-play text-lg"></div>
            <span>Start Game</span>
          </button>
          
          <button
            onClick={resetGame}
            className="btn-secondary flex items-center space-x-2"
          >
            <div className="icon-rotate-ccw text-lg"></div>
            <span>Reset</span>
          </button>
          
          <button
            onClick={toggleFullscreen}
            className="btn-secondary flex items-center space-x-2"
          >
            <div className={`text-lg ${isFullscreen ? 'icon-minimize' : 'icon-maximize'}`}></div>
            <span>{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
          </button>
        </div>
        
        <div className="text-sm text-[var(--text-secondary)] text-center max-w-md">
          <p>Use arrow keys or A/D to move the paddle. Press spacebar to launch the ball.</p>
        </div>
      </div>
    );
  } catch (error) {
    console.error('GameCanvas component error:', error);
    return null;
  }
}