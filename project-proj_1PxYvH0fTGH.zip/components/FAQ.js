function FAQ() {
  const [openFAQ, setOpenFAQ] = React.useState(null);
  
  try {
    const faqs = [
      {
        question: "How do I control the paddle?",
        answer: "Use the left and right arrow keys or the A and D keys to move the paddle horizontally across the bottom of the screen."
      },
      {
        question: "What happens when I break all the blocks?",
        answer: "When you successfully break all blocks on the screen, you advance to the next level with a new arrangement of blocks and increased difficulty."
      },
      {
        question: "Can I play in fullscreen mode?",
        answer: "Yes! Click the fullscreen button below the game canvas to enjoy an immersive gaming experience."
      },
      {
        question: "What are the different colored blocks?",
        answer: "Different colored blocks have varying point values. Red blocks typically give the most points, while blue and green blocks give moderate points."
      },
      {
        question: "How do power-ups work?",
        answer: "Power-ups drop from certain blocks when destroyed. Catch them with your paddle to activate special abilities like multi-ball, extended paddle, or extra points."
      },
      {
        question: "Is there a high score system?",
        answer: "Yes, your current score is displayed above the game. Try to beat your personal best with each playthrough!"
      }
    ];

    const toggleFAQ = (index) => {
      setOpenFAQ(openFAQ === index ? null : index);
    };

    return (
      <section className="py-16 bg-[var(--bg-light)]" data-name="faq" data-file="components/FAQ.js">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[var(--text-primary)] mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              Get answers to common questions about playing Block Breaker
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="section-card">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex items-center justify-between text-left"
                >
                  <h3 className="text-lg font-semibold text-[var(--text-primary)]">
                    {faq.question}
                  </h3>
                  <div className={`icon-chevron-down text-lg text-[var(--primary-color)] transition-transform duration-200 ${
                    openFAQ === index ? 'rotate-180' : ''
                  }`}></div>
                </button>
                
                {openFAQ === index && (
                  <div className="mt-4 pt-4 border-t border-[var(--border-color)]">
                    <p className="text-[var(--text-secondary)]">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('FAQ component error:', error);
    return null;
  }
}