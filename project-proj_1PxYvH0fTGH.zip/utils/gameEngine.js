class GameEngine {
  constructor(canvas, scoreCallback) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.scoreCallback = scoreCallback;
    
    this.gameState = 'stopped'; // stopped, playing, paused, gameOver
    this.score = 0;
    this.level = 1;
    
    this.initializeGameObjects();
    this.bindEvents();
    this.draw();
  }
  
  initializeGameObjects() {
    // Paddle
    this.paddle = {
      x: this.canvas.width / 2 - 60,
      y: this.canvas.height - 20,
      width: 120,
      height: 15,
      speed: 8
    };
    
    // Ball
    this.ball = {
      x: this.canvas.width / 2,
      y: this.canvas.height - 50,
      radius: 8,
      dx: 5,
      dy: -5,
      launched: false
    };
    
    // Create blocks
    this.createBlocks();
    
    // Input state
    this.keys = {};
  }
  
  createBlocks() {
    this.blocks = [];
    const rows = 6;
    const cols = 10;
    const blockWidth = 75;
    const blockHeight = 25;
    const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6'];
    
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        this.blocks.push({
          x: col * (blockWidth + 5) + 5,
          y: row * (blockHeight + 5) + 50,
          width: blockWidth,
          height: blockHeight,
          color: colors[row],
          points: (rows - row) * 10
        });
      }
    }
  }
  
  bindEvents() {
    document.addEventListener('keydown', (e) => {
      this.keys[e.key] = true;
      if (e.key === ' ' && !this.ball.launched && this.gameState === 'playing') {
        this.launchBall();
      }
    });
    
    document.addEventListener('keyup', (e) => {
      this.keys[e.key] = false;
    });
  }
  
  launchBall() {
    this.ball.launched = true;
    this.ball.dx = (Math.random() - 0.5) * 8;
    this.ball.dy = -Math.abs(this.ball.dy);
  }
  
  start() {
    this.gameState = 'playing';
    this.gameLoop();
  }
  
  reset() {
    this.gameState = 'stopped';
    this.score = 0;
    this.level = 1;
    this.initializeGameObjects();
    this.scoreCallback(0);
    this.draw();
  }
  
  gameLoop() {
    if (this.gameState === 'playing') {
      this.update();
      this.draw();
      requestAnimationFrame(() => this.gameLoop());
    }
  }
  
  update() {
    // Move paddle
    if ((this.keys['ArrowLeft'] || this.keys['a'] || this.keys['A']) && this.paddle.x > 0) {
      this.paddle.x -= this.paddle.speed;
    }
    if ((this.keys['ArrowRight'] || this.keys['d'] || this.keys['D']) && 
        this.paddle.x < this.canvas.width - this.paddle.width) {
      this.paddle.x += this.paddle.speed;
    }
    
    // Move ball
    if (this.ball.launched) {
      this.ball.x += this.ball.dx;
      this.ball.y += this.ball.dy;
    } else {
      // Ball follows paddle when not launched
      this.ball.x = this.paddle.x + this.paddle.width / 2;
    }
    
    // Ball collision with walls
    if (this.ball.x - this.ball.radius < 0 || this.ball.x + this.ball.radius > this.canvas.width) {
      this.ball.dx = -this.ball.dx;
    }
    if (this.ball.y - this.ball.radius < 0) {
      this.ball.dy = -this.ball.dy;
    }
    
    // Ball collision with paddle
    if (this.ball.launched && 
        this.ball.y + this.ball.radius > this.paddle.y &&
        this.ball.y - this.ball.radius < this.paddle.y + this.paddle.height &&
        this.ball.x > this.paddle.x &&
        this.ball.x < this.paddle.x + this.paddle.width) {
      
      // Calculate hit position on paddle for angle control
      const hitPos = (this.ball.x - this.paddle.x) / this.paddle.width;
      this.ball.dx = (hitPos - 0.5) * 10;
      this.ball.dy = -Math.abs(this.ball.dy);
    }
    
    // Ball collision with blocks
    for (let i = this.blocks.length - 1; i >= 0; i--) {
      const block = this.blocks[i];
      if (this.ball.x > block.x &&
          this.ball.x < block.x + block.width &&
          this.ball.y > block.y &&
          this.ball.y < block.y + block.height) {
        
        this.ball.dy = -this.ball.dy;
        this.score += block.points;
        this.scoreCallback(this.score);
        this.blocks.splice(i, 1);
        
        // Check win condition
        if (this.blocks.length === 0) {
          this.nextLevel();
        }
        break;
      }
    }
    
    // Game over condition
    if (this.ball.y > this.canvas.height) {
      this.gameState = 'gameOver';
    }
  }
  
  nextLevel() {
    this.level++;
    this.ball.launched = false;
    this.ball.x = this.paddle.x + this.paddle.width / 2;
    this.ball.y = this.canvas.height - 50;
    this.createBlocks();
  }
  
  draw() {
    // Clear canvas
    this.ctx.fillStyle = '#000000';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Draw paddle
    this.ctx.fillStyle = '#ffffff';
    this.ctx.fillRect(this.paddle.x, this.paddle.y, this.paddle.width, this.paddle.height);
    
    // Draw ball
    this.ctx.beginPath();
    this.ctx.arc(this.ball.x, this.ball.y, this.ball.radius, 0, Math.PI * 2);
    this.ctx.fillStyle = '#ffffff';
    this.ctx.fill();
    
    // Draw blocks
    this.blocks.forEach(block => {
      this.ctx.fillStyle = block.color;
      this.ctx.fillRect(block.x, block.y, block.width, block.height);
      
      // Block border
      this.ctx.strokeStyle = '#ffffff';
      this.ctx.lineWidth = 1;
      this.ctx.strokeRect(block.x, block.y, block.width, block.height);
    });
    
    // Draw UI text
    this.ctx.fillStyle = '#ffffff';
    this.ctx.font = '20px Arial';
    
    if (this.gameState === 'stopped') {
      this.ctx.fillText('Press Start to Play', this.canvas.width / 2 - 80, this.canvas.height / 2);
    } else if (this.gameState === 'playing' && !this.ball.launched) {
      this.ctx.fillText('Press SPACE to launch ball', this.canvas.width / 2 - 120, this.canvas.height / 2);
    } else if (this.gameState === 'gameOver') {
      this.ctx.fillText('Game Over! Press Reset to try again', this.canvas.width / 2 - 150, this.canvas.height / 2);
    }
    
    // Level indicator
    this.ctx.fillText(`Level: ${this.level}`, 10, 30);
  }
  
  destroy() {
    this.gameState = 'stopped';
  }
}