When project is updated or new features are added
- Always check if README.md in trickle/notes needs updating
- Update project overview when major features are added
- Update technical stack information when dependencies change
- Update pages structure when new HTML pages are created
- Keep feature list current with actual implemented functionality
- Update maintenance notes when new requirements are identified