function Footer() {
  try {
    return (
      <footer className="bg-[var(--text-primary)] text-white py-12" data-name="footer" data-file="components/Footer.js">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-[var(--primary-color)] rounded flex items-center justify-center">
                  <div className="icon-gamepad-2 text-xl text-white"></div>
                </div>
                <h3 className="text-xl font-bold">Block Breaker</h3>
              </div>
              <p className="text-gray-300">
                The ultimate brick breaking game experience. Challenge yourself and break all the blocks!
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Game Features</h4>
              <ul className="space-y-2 text-gray-300">
                <li>• Multiple difficulty levels</li>
                <li>• Power-ups and special effects</li>
                <li>• Fullscreen gaming mode</li>
                <li>• Responsive controls</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="blog.html" className="text-gray-300 hover:text-white transition-colors">
                    Game Blog
                  </a>
                </li>
                <li>
                  <a href="tips.html" className="text-gray-300 hover:text-white transition-colors">
                    Tips & Strategies
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              © 2025 Block Breaker Game. All rights reserved. Built for endless arcade fun.
            </p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}