function Header() {
  try {
    const navigateToPage = (page) => {
      window.location.href = page;
    };

    return (
      <header className="bg-white shadow-md" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded flex items-center justify-center">
                <div className="icon-gamepad-2 text-xl text-white"></div>
              </div>
              <h1 className="text-2xl font-bold text-[var(--text-primary)]">Block Breaker</h1>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <a href="index.html" className="text-[var(--text-primary)] hover:text-[var(--primary-color)] transition-colors">
                Home
              </a>
              <button 
                onClick={() => navigateToPage('blog.html')}
                className="text-[var(--text-primary)] hover:text-[var(--primary-color)] transition-colors"
              >
                Blog
              </button>
              <button 
                onClick={() => navigateToPage('tips.html')}
                className="text-[var(--text-primary)] hover:text-[var(--primary-color)] transition-colors"
              >
                Tips & Strategies
              </button>
            </nav>
            
            <div className="md:hidden">
              <div className="icon-menu text-xl text-[var(--text-primary)]"></div>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}