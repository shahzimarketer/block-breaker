function HowToPlay() {
  try {
    const instructions = [
      {
        icon: 'target',
        title: 'Objective',
        description: 'Break all the colored blocks on the screen using the bouncing ball.'
      },
      {
        icon: 'gamepad-2',
        title: 'Controls',
        description: 'Use arrow keys or A/D keys to move the paddle left and right.'
      },
      {
        icon: 'zap',
        title: 'Power-ups',
        description: 'Collect falling power-ups to get special abilities and bonus points.'
      },
      {
        icon: 'trophy',
        title: 'Scoring',
        description: 'Earn points by breaking blocks. Different colored blocks give different scores.'
      }
    ];

    return (
      <section className="py-16 bg-white" data-name="how-to-play" data-file="components/HowToPlay.js">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[var(--text-primary)] mb-4">
              How to Play Block Breaker
            </h2>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              Master the art of block breaking with these simple yet effective gameplay mechanics
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {instructions.map((item, index) => (
              <div key={index} className="section-card text-center">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-6">
                  <div className={`icon-${item.icon} text-2xl text-white`}></div>
                </div>
                <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                <p className="text-[var(--text-secondary)]">{item.description}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-12 section-card">
            <h3 className="text-2xl font-bold mb-6 text-center">Game Tips</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2 text-[var(--primary-color)]">Paddle Strategy</h4>
                <p className="text-[var(--text-secondary)]">Hit the ball with different parts of the paddle to control its angle and direction.</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2 text-[var(--primary-color)]">Power-up Priority</h4>
                <p className="text-[var(--text-secondary)]">Always try to catch power-ups, but don't risk losing the ball for them.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('HowToPlay component error:', error);
    return null;
  }
}